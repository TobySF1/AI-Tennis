import { supabase } from "./supabase";
import type { Session } from "@supabase/supabase-js";
import React, { useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import ReactMarkdown from "react-markdown";

type Shot =
  | "serve"
  | "forehand"
  | "backhand"
  | "volley"
  | "backhand slice"
  | "forehand slice"
  | "overhead"
  | "dropshot"
  | "lob"
  | "pick-up shot"
  | "half volley";

type Category = "beginner" | "intermediate" | "advanced";

interface Coach {
  id: number;
  name: string;
  hours: string;
  description: string;
  rates: string;
  photo: string | null;
}

interface Account {
  id: string;
  email: string | null;
  name: string;
  age: string | number;
  ability: string;
  photo: string | null;
  location?: string;
  handedness?: string;
}

const SHOTS: Shot[] = [
  "serve",
  "forehand",
  "backhand",
  "volley",
  "backhand slice",
  "forehand slice",
  "overhead",
  "dropshot",
  "lob",
  "pick-up shot",
  "half volley",
];

const CATEGORIES: Category[] = ["beginner", "intermediate", "advanced"];

const TUTORIALS: Record<Shot, Record<Category, string[]>> = {
  serve: {
    beginner: ["Good ball toss", "Basic swing motion", "Hit out front"],
    intermediate: ["Toss consistency", "Flat serve basics", "Pronation"],
    advanced: [
      "Kick serve mechanics",
      "Slice serve technique",
      "Flat serve and wrist snap",
    ],
  },
  forehand: {
    beginner: ["Proper grip", "Swing low to high", "Contact in front"],
    intermediate: ["Unit turn", "Follow through", "Topspin basics"],
    advanced: [
      "Open stance footwork",
      "Acceleration and lag",
      "Heavy topspin technique",
    ],
  },
  backhand: {
    beginner: ["Eastern grip", "Two hands", "Step into shot"],
    intermediate: ["Hip rotation", "Extend arms", "Early preparation"],
    advanced: [
      "One-handed backhand drive",
      "High ball adaptation",
      "Backhand passing shot",
    ],
  },
  volley: {
    beginner: ["Continental grip", "No swing", "Punch motion"],
    intermediate: ["Footwork forward", "Low center of gravity", "Stick volley"],
    advanced: ["Reflex volley", "Drop volley", "Transition volley"],
  },
  "backhand slice": {
    beginner: ["Continental grip", "Knife motion", "Use shoulder"],
    intermediate: ["Low contact", "Deep follow through", "Chop for defense"],
    advanced: [
      "Floating slice for approach",
      "Drop slice",
      "Slice passing shot",
    ],
  },
  "forehand slice": {
    beginner: ["Open face", "Chop down", "Relaxed wrist"],
    intermediate: ["Short angle", "Depth control", "Mixing pace"],
    advanced: ["Aggressive slice", "Low skidding ball", "Defensive lob"],
  },
  overhead: {
    beginner: ["Trophy position", "Track the ball", "Hit high"],
    intermediate: ["Shoulder rotation", "Snap wrist", "Move feet"],
    advanced: [
      "Scissor kick overhead",
      "Overhead angles",
      "Chase-back overhead",
    ],
  },
  dropshot: {
    beginner: ["Soft hands", "Open face", "Short backswing"],
    intermediate: ["Disguise motion", "Timing", "Angle dropshot"],
    advanced: [
      "Backspin dropshot",
      "Dropshot from baseline",
      "Double-bounce dropshot",
    ],
  },
  lob: {
    beginner: ["Full follow through", "Aim high", "Use topspin"],
    intermediate: ["Defensive lob", "Offensive lob", "Timing"],
    advanced: ["Running lob", "Lob on the run", "Angle lob"],
  },
  "pick-up shot": {
    beginner: ["Bend knees", "Short backswing", "Lift up"],
    intermediate: ["Open face", "Quick wrist", "Brush up"],
    advanced: [
      "Half-volley pick-up",
      "Short angle pick-up",
      "Low slice pick-up",
    ],
  },
  "half volley": {
    beginner: ["Stay low", "Minimal swing", "Soft grip"],
    intermediate: ["Move forward", "Weight transfer", "Early contact"],
    advanced: [
      "Aggressive half volley",
      "Half volley drop shot",
      "Transition half volley",
    ],
  },
};

function Card({
  children,
  style = {},
}: {
  children: React.ReactNode;
  style?: React.CSSProperties;
}) {
  return (
    <div
      style={{
        background: "#fff",
        borderRadius: 16,
        boxShadow: "0 2px 12px rgba(0,0,0,0.10)",
        padding: 24,
        margin: "24px 0",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function App() {
  const [page, setPage] = useState<
    "home" | "analysis" | "coaching" | "program" | "myshots" | "accounts"
  >("home");

  // --- Login States
  const [session, setSession] = useState<Session | null>(null);
  const accessToken = session?.access_token || null;

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [signupMode, setSignupMode] = useState(false);
  const userEmail = session?.user?.email || null;

  // --- Account Listing/Adding States

  const [accounts, setAccounts] = useState<Account[]>([]);
  const [accountsLoading, setAccountsLoading] = useState(false);

  // --- AI Analysis States
  const [selectedShot, setSelectedShot] = useState<Shot>("serve");
  const [video, setVideo] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState("");
  const [analyzing, setAnalyzing] = useState(false);

  // --- Shot history & "Analyze My Shots" ---
  const [myShotsSummary, setMyShotsSummary] = useState<any>(null);

  // --- Coach Listing/Adding States
  const [coaches, setCoaches] = useState<Coach[]>([]);
  const [coachForm, setCoachForm] = useState({
    name: "",
    hours: "",
    description: "",
    rates: "",
  });
  const [coachPhoto, setCoachPhoto] = useState<File | null>(null);

  // --- Message Coach
  const [msgCoachId, setMsgCoachId] = useState<number | null>(null);
  const [msgPlayerName, setMsgPlayerName] = useState("");
  const [msgText, setMsgText] = useState("");
  const [msgStatus, setMsgStatus] = useState("");

  // --- Tennis Program
  const [selectedCategory, setSelectedCategory] =
    useState<Category>("beginner");
  const [selectedTutorialShot, setSelectedTutorialShot] =
    useState<Shot>("serve");

  React.useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data }) => setSession(data.session || null));
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_e, sess) => {
      setSession(sess);
    });
    return () => subscription.unsubscribe();
  }, []);

  // Load accounts
  React.useEffect(() => {
    if (page === "accounts") {
      setAccountsLoading(true);
      fetch("/api/accounts")
        .then((r) => r.json())
        .then((rows) => setAccounts(rows || []))
        .catch(() => setAccounts([]))
        .finally(() => setAccountsLoading(false));
    }
  }, [page]);

  // Load coaches
  React.useEffect(() => {
    if (page === "coaching") {
      fetch("/api/coaches")
        .then((res) => res.json())
        .then(setCoaches);
    }
  }, [page]);

  // Then log in after short delay so user sees the message

  async function handleLogin(e: FormEvent) {
    e.preventDefault();
    const redirectTo = `${window.location.origin}/auth/callback`;

    if (signupMode) {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: redirectTo },
      });
      if (error) return alert(error.message);
      alert("Check your email to confirm your account, then log in.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) return alert(error.message);
    }

    setEmail("");
    setPassword("");
  }

  async function handleLogout() {
    await supabase.auth.signOut();
  }

  // --- AI Analysis upload handler, now saves for logged in user ---
  const handleAnalyze = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!video) return alert("Please upload a video.");
    if (!userEmail) return alert("Please login first!");

    setAnalyzing(true);

    try {
      // 1) Upload to your analysis endpoint (returns { analysis })
      const formData = new FormData();
      formData.append("shotType", selectedShot);
      formData.append("video", video);
      formData.append("username", userEmail); // optional, server really uses token

      const analyzeRes = await fetch("/api/analyze", {
        method: "POST",
        body: formData,
      });

      if (!analyzeRes.ok) {
        const txt = await analyzeRes.text();
        throw new Error(`Analyze failed (${analyzeRes.status}): ${txt}`);
      }

      const analyzeJson = await analyzeRes.json();
      const analysisText = analyzeJson.analysis || "No analysis returned.";
      setAnalysis(analysisText);

      // 2) Save the analysis to your DB (must include the Supabase access token)
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;

      const saveRes = await fetch("/api/save-analysis", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          shotType: selectedShot,
          analysis: analysisText,
        }),
      });

      if (!saveRes.ok) {
        const saveText = await saveRes.text();
        throw new Error(`Save failed (${saveRes.status}): ${saveText}`);
      }

      // 3) Refresh the “Analyze My Shots” summary (optional UI update)
      await handleAnalyzeShots();
    } catch (err: any) {
      console.error(err);
      alert(err.message || "Analyze/save failed");
    } finally {
      setAnalyzing(false);
    }
  };

  async function handleAnalyzeShots() {
    if (!userEmail) return;

    setPage("myshots");
    setMyShotsSummary(null);

    try {
      const res = await fetch("/api/analyze-shots", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        },
        body: JSON.stringify({}),
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setMyShotsSummary(data.summary || {});
    } catch (err) {
      setMyShotsSummary({});
      alert(
        "Couldn't analyze your shots. Try uploading a shot first, then try again.",
      );
      console.error("analyze-shots failed", err);
    }
  }

  // Coach add handler
  const handleAddCoach = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData();
    Object.entries(coachForm).forEach(([k, v]) => formData.append(k, v));
    if (coachPhoto) formData.append("photo", coachPhoto);
    await fetch("/api/coaches", { method: "POST", body: formData });
    setCoachForm({ name: "", hours: "", description: "", rates: "" });
    setCoachPhoto(null);
    fetch("/api/coaches")
      .then((res) => res.json())
      .then(setCoaches);
  };

  // Send message to coach
  const handleMsgCoach = async (coachId: number) => {
    await fetch("/api/message", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        coachId,
        playerName: msgPlayerName,
        message: msgText,
      }),
    });
    setMsgStatus("Message sent!");
    setTimeout(() => setMsgStatus(""), 2000);
    setMsgCoachId(null);
    setMsgText("");
    setMsgPlayerName("");
  };

  // --- MAIN UI ---
  return (
    <div
      style={{
        maxWidth: 900,
        margin: "0 auto",
        fontFamily: "system-ui, sans-serif",
        background: "#f6f7fa",
        minHeight: "100vh",
        padding: "32px 12px",
      }}
    >
      <h1 style={{ textAlign: "center", letterSpacing: 1.2, marginBottom: 8 }}>
        🎾 Tennis AI App
      </h1>
      <nav
        style={{
          display: "flex",
          gap: 12,
          justifyContent: "center",
          marginBottom: 36,
        }}
      >
        <button onClick={() => setPage("home")}>Home</button>
        <button onClick={() => setPage("analysis")}>AI Analysis</button>
        <button onClick={() => setPage("coaching")}>Coaching</button>
        <button onClick={() => setPage("accounts")}>Accounts</button>
        <button onClick={() => setPage("program")}>Tennis Programs</button>
        {userEmail && (
          <button onClick={handleAnalyzeShots}>Analyze My Shots</button>
        )}
        {session ? (
          <button onClick={handleLogout} style={{ marginLeft: "auto" }}>
            Logout ({userEmail})
          </button>
        ) : null}
      </nav>

      {page === "home" && (
        <Card>
          {userEmail ? (
            <>
              <h2 style={{ marginTop: 0 }}>Welcome back, {userEmail}!</h2>
              <p>
                Get <b>video-based AI shot analysis</b>, find experienced
                coaches, or follow <b>tailored tennis training programs</b>.
                Level up your tennis with tech!
              </p>
              <button onClick={handleAnalyzeShots} style={{ marginTop: 12 }}>
                Analyze My Shots
              </button>
            </>
          ) : (
            <>
              <h2 style={{ marginTop: 0 }}>Welcome to Tennis AI!</h2>
              <form onSubmit={handleLogin} style={{ margin: "16px 0" }}>
                <input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{ marginRight: 8, padding: 6 }}
                  required
                />
                <input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  style={{ marginRight: 8, padding: 6 }}
                  required
                />
                <button type="submit" style={{ padding: "6px 14px" }}>
                  {signupMode ? "Sign up" : "Login"}
                </button>
                <button
                  type="button"
                  style={{ marginLeft: 10 }}
                  onClick={() => setSignupMode((s) => !s)}
                >
                  {signupMode ? "Have an account? Login" : "Create account"}
                </button>
              </form>
              <p>
                Get <b>video-based AI shot analysis</b>, find experienced
                coaches, or follow <b>tailored tennis training programs</b>.
                Level up your tennis with tech!
              </p>
            </>
          )}
        </Card>
      )}

      {page === "accounts" && (
        <Card>
          <h2>Accounts</h2>
          {accountsLoading && <div>Loading...</div>}
          {!accountsLoading && accounts.length === 0 && (
            <div>No accounts found.</div>
          )}
          <div
            style={{
              display: "grid",
              gap: 16,
              gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
            }}
          >
            {accounts.map((a) => (
              <div
                key={a.id}
                style={{
                  background: "#fff",
                  border: "1px solid #e5e7eb",
                  borderRadius: 12,
                  padding: 16,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 12,
                    marginBottom: 10,
                  }}
                >
                  <img
                    src={a.photo || "https://via.placeholder.com/64?text=👤"}
                    alt="Profile"
                    style={{
                      width: 64,
                      height: 64,
                      borderRadius: "50%",
                      objectFit: "cover",
                      border: "1px solid #e5e7eb",
                    }}
                  />
                  <div>
                    <div style={{ fontWeight: 700 }}>{a.name || "—"}</div>
                    <div style={{ fontSize: 12, color: "#6b7280" }}>
                      {a.email || "—"}
                    </div>
                  </div>
                </div>
                <div>
                  <b>Age:</b> {a.age || "—"}
                </div>
                <div>
                  <b>Tennis ability:</b> {a.ability || "—"}
                </div>
                <div>
                  <b>Location:</b> {a.location || "—"}
                </div>
                <div>
                  <b>Handedness:</b> {a.handedness || "—"}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {page === "analysis" && (
        <Card>
          <h2>AI Shot Analysis</h2>
          <form onSubmit={handleAnalyze} style={{ marginBottom: 18 }}>
            <label>
              <b>Select Shot Type:</b>{" "}
              <select
                value={selectedShot}
                onChange={(e) => setSelectedShot(e.target.value as Shot)}
                style={{ margin: "0 8px 0 0" }}
              >
                {SHOTS.map((s) => (
                  <option key={s} value={s}>
                    {s.charAt(0).toUpperCase() + s.slice(1)}
                  </option>
                ))}
              </select>
            </label>
            <br />
            <label>
              <b>Upload a video (max 5 sec):</b>{" "}
              <input
                type="file"
                accept="video/*"
                onChange={(e: ChangeEvent<HTMLInputElement>) => {
                  if (e.target.files && e.target.files.length > 0) {
                    setVideo(e.target.files[0]);
                  }
                }}
                style={{ margin: "10px 0" }}
              />
            </label>
            <br />
            <button
              type="submit"
              disabled={analyzing}
              style={{ marginTop: 12 }}
            >
              {analyzing ? "Analyzing..." : "Analyze"}
            </button>
          </form>
          {analysis && (
            <Card
              style={{
                background: "#f7fcff",
                borderLeft: "4px solid #32b5fc",
                margin: 0,
              }}
            >
              <h3 style={{ marginTop: 0, color: "#1484be" }}>
                📊 Shot Analysis
              </h3>
              <ReactMarkdown
                children={analysis}
                components={{
                  h1: (props) => <h3 style={{ color: "#0c80a0" }} {...props} />,
                  h2: (props) => <h4 style={{ color: "#13799d" }} {...props} />,
                  ul: (props) => (
                    <ul style={{ margin: "8px 0 16px 18px" }} {...props} />
                  ),
                  ol: (props) => (
                    <ol style={{ margin: "8px 0 16px 18px" }} {...props} />
                  ),
                  li: (props) => <li style={{ lineHeight: 1.7 }} {...props} />,
                  p: (props) => <p style={{ margin: "8px 0" }} {...props} />,
                }}
              />
            </Card>
          )}
        </Card>
      )}

      {page === "coaching" && (
        <Card>
          <h2>Coaching</h2>
          <div style={{ display: "flex", gap: 40, flexWrap: "wrap" }}>
            {/* Players: See coaches */}
            <div style={{ flex: 1, minWidth: 270 }}>
              <h3 style={{ color: "#2171b7" }}>For Players</h3>
              {coaches.length === 0 && <p>No coaches listed yet.</p>}
              <div
                style={{ display: "flex", flexDirection: "column", gap: 20 }}
              >
                {coaches.map((c) => (
                  <Card
                    key={c.id}
                    style={{
                      border: "1px solid #e4e6ed",
                      padding: 16,
                      margin: 0,
                      boxShadow: "0 1px 8px rgba(44,105,171,0.06)",
                      background: "#fafdff",
                    }}
                  >
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 18 }}
                    >
                      {c.photo && (
                        <img
                          src={c.photo}
                          alt="Coach"
                          style={{
                            width: 64,
                            height: 64,
                            objectFit: "cover",
                            borderRadius: "50%",
                            border: "2px solid #e3e9f2",
                          }}
                        />
                      )}
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 18 }}>
                          {c.name}
                        </div>
                        <div style={{ fontStyle: "italic", margin: "3px 0" }}>
                          {c.description}
                        </div>
                        <div>🕒 Hours: {c.hours}</div>
                        <div>💲 Rates: {c.rates}</div>
                        <button
                          onClick={() => setMsgCoachId(c.id)}
                          style={{
                            marginTop: 8,
                            background: "#22c55e",
                            color: "white",
                            border: "none",
                            borderRadius: 6,
                            padding: "6px 14px",
                            cursor: "pointer",
                          }}
                        >
                          Message Coach
                        </button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
              {msgCoachId && (
                <Card style={{ background: "#f7fcf7" }}>
                  <h4>Message Coach</h4>
                  <input
                    placeholder="Your Name"
                    value={msgPlayerName}
                    onChange={(e) => setMsgPlayerName(e.target.value)}
                    style={{ width: "60%", margin: "4px 0" }}
                  />
                  <br />
                  <textarea
                    placeholder="Message..."
                    value={msgText}
                    onChange={(e) => setMsgText(e.target.value)}
                    style={{ width: "100%", margin: "4px 0" }}
                  />
                  <br />
                  <button
                    onClick={() => handleMsgCoach(msgCoachId)}
                    style={{
                      marginTop: 4,
                      background: "#2563eb",
                      color: "white",
                      border: "none",
                      borderRadius: 6,
                      padding: "6px 14px",
                      cursor: "pointer",
                    }}
                  >
                    Send
                  </button>
                  <button
                    onClick={() => setMsgCoachId(null)}
                    style={{
                      marginLeft: 8,
                      background: "#e2e8f0",
                      color: "#333",
                      border: "none",
                      borderRadius: 6,
                      padding: "6px 14px",
                      cursor: "pointer",
                    }}
                  >
                    Cancel
                  </button>
                  {msgStatus && <div style={{ marginTop: 8 }}>{msgStatus}</div>}
                </Card>
              )}
            </div>

            {/* Coaches: Add yourself */}
            <div style={{ flex: 1, minWidth: 270 }}>
              <h3 style={{ color: "#f59e42" }}>For Coaches</h3>
              <form
                onSubmit={handleAddCoach}
                style={{ background: "#fff7ed", padding: 18, borderRadius: 10 }}
              >
                <input
                  placeholder="Name"
                  value={coachForm.name}
                  onChange={(e) =>
                    setCoachForm((f) => ({ ...f, name: e.target.value }))
                  }
                  required
                  style={{ width: "100%", marginBottom: 8, padding: 6 }}
                />
                <input
                  placeholder="Hours"
                  value={coachForm.hours}
                  onChange={(e) =>
                    setCoachForm((f) => ({ ...f, hours: e.target.value }))
                  }
                  required
                  style={{ width: "100%", marginBottom: 8, padding: 6 }}
                />
                <input
                  placeholder="Description"
                  value={coachForm.description}
                  onChange={(e) =>
                    setCoachForm((f) => ({ ...f, description: e.target.value }))
                  }
                  required
                  style={{ width: "100%", marginBottom: 8, padding: 6 }}
                />
                <input
                  placeholder="Rates"
                  value={coachForm.rates}
                  onChange={(e) =>
                    setCoachForm((f) => ({ ...f, rates: e.target.value }))
                  }
                  required
                  style={{ width: "100%", marginBottom: 8, padding: 6 }}
                />
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    if (e.target.files && e.target.files.length > 0) {
                      setCoachPhoto(e.target.files[0]);
                    }
                  }}
                  style={{ margin: "8px 0" }}
                />
                <br />
                <button
                  type="submit"
                  style={{
                    marginTop: 8,
                    background: "#f59e42",
                    color: "white",
                    border: "none",
                    borderRadius: 8,
                    padding: "7px 20px",
                    cursor: "pointer",
                  }}
                >
                  Add/Update Coach
                </button>
              </form>
            </div>
          </div>
        </Card>
      )}

      {page === "program" && (
        <Card>
          <h2>Tennis Training Programs</h2>
          <div style={{ marginBottom: 18 }}>
            <label>
              <b>Category:</b>{" "}
              <select
                value={selectedCategory}
                onChange={(e) =>
                  setSelectedCategory(e.target.value as Category)
                }
                style={{ marginRight: 16 }}
              >
                {CATEGORIES.map((c) => (
                  <option key={c}>
                    {c.charAt(0).toUpperCase() + c.slice(1)}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <b>Shot:</b>{" "}
              <select
                value={selectedTutorialShot}
                onChange={(e) =>
                  setSelectedTutorialShot(e.target.value as Shot)
                }
              >
                {SHOTS.map((s) => (
                  <option key={s} value={s}>
                    {s.charAt(0).toUpperCase() + s.slice(1)}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <Card style={{ background: "#f8fafc" }}>
            <h3 style={{ marginTop: 0 }}>
              {selectedCategory.charAt(0).toUpperCase() +
                selectedCategory.slice(1)}{" "}
              {selectedTutorialShot.charAt(0).toUpperCase() +
                selectedTutorialShot.slice(1)}{" "}
              Tutorial
            </h3>
            <ul style={{ marginLeft: 24 }}>
              {(
                TUTORIALS[selectedTutorialShot][selectedCategory] || [
                  "(Tutorial coming soon)",
                ]
              ).map((tip, idx) => (
                <li key={idx} style={{ marginBottom: 4 }}>
                  {tip}
                </li>
              ))}
            </ul>
            {/* You could add embedded tutorial videos here if you want! */}
          </Card>
        </Card>
      )}
      {/* --- Analyze My Shots Page --- */}
      {page === "myshots" && userEmail && (
        <Card>
          <h2>📈 Analyze My Shots</h2>
          {!myShotsSummary && <div>Loading...</div>}
          {myShotsSummary && (
            <>
              {Object.keys(myShotsSummary).length === 0 && (
                <div>No shots analyzed yet!</div>
              )}
              {Object.entries(myShotsSummary).map(([shot, info]: any) => (
                <div key={shot} style={{ marginBottom: 14 }}>
                  <b>{shot.charAt(0).toUpperCase() + shot.slice(1)}:</b>{" "}
                  <span>{info.total} analyzed.</span>
                  {info.misses.length > 0 && (
                    <ul>
                      {info.misses.map((m: string, idx: number) => (
                        <li key={idx}>{m}</li>
                      ))}
                    </ul>
                  )}
                  {info.misses.length === 0 && (
                    <span style={{ color: "green" }}>
                      Looking good! No major repeated issues found.
                    </span>
                  )}
                </div>
              ))}
            </>
          )}
        </Card>
      )}
    </div>
  );
}
export default App;
