import 'dotenv/config';
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE!, // server only
);

import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import multer from "multer";
import bcrypt from "bcryptjs";

const app = express();
const upload = multer({ dest: "uploads/" });

const GEMINI_API_KEY = "AIzaSyDcIe-pmIqI8RSpUVeB01tTif_5KYPFc9g";

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));


// who am i
app.get("/api/whoami", async (req, res) => {
  try {
    const user = await getUserFromAuthHeader(req);
    if (!user) return res.status(401).json({ error: "Not authenticated" });
    res.json({ id: user.id, email: user.email });
  } catch (e:any) {
    res.status(500).json({ error: e.message || "whoami failed" });
  }
});

// --- Serve the built React app (for production, comment out for dev) ---
app.use(express.static(path.join(process.cwd(), "..", "client", "dist")));
app.get("*", (req, res) => {
  res.sendFile(path.join(process.cwd(), "..", "client", "dist", "index.html"));
});

// save analysis (JSON body)
app.post("/api/save-analysis", async (req, res) => {
  try {
    const user = await getUserFromAuthHeader(req);
    if (!user) return res.status(401).json({ error: "Not authenticated" });

    const { shotType, analysis } = req.body;
    if (!shotType || !analysis) {
      return res.status(400).json({ error: "Missing shotType or analysis" });
    }

    const { error } = await supabaseAdmin.from("shot_analyses").insert({
      user_id: user.id,
      email: user.email,
      shot_type: shotType,
      analysis,
    });

    if (error) return res.status(500).json({ error: error.message });
    res.json({ ok: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message || "Failed to save analysis" });
  }
});

    const users = readUsers();
    let user = users.users.find((u) => u.username === id);

    // auto-create user if not found
    if (!user) {
      user = { username: id, passwordHash: null, analyses: [] };
      users.users.push(user);
    }

    user.analyses.push({
      shotType,
      analysis,
      timestamp: Date.now(),
    });

    writeUsers(users);
    res.json({ ok: true });
  });


  if (error) return res.status(500).json({ error: error.message });
  res.json({ ok: true });
});

app.post("/api/signup", async (req, res) => {
  const { email, password } = req.body;
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  if (error) return res.status(400).json({ error: error.message });
  res.json({ user: data.user });
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  if (error) return res.status(400).json({ error: error.message });
  res.json({ session: data.session, user: data.user });
});

app.get("/api/my-analysis", async (req, res) => {
  const { user_id } = req.query;

  const { data, error } = await supabaseAdmin
    .from("analyses")
    .select("*")
    .eq("user_id", user_id);

  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});


// --- Analyze all shots (simple pattern matching to build suggestions) ---
app.post("/api/analyze-shots", async (req, res) => {
  try {
    const user = await getUserFromAuthHeader(req);
    if (!user) return res.status(401).json({ error: "Not authenticated" });

    const { data, error } = await supabaseAdmin
      .from("shot_analyses")
      .select("shot_type, analysis, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) return res.status(500).json({ error: error.message });

    const analyses = data || [];

    // your existing summary logic:
    const SHOTS = [
      "forehand","serve","backhand","volley","lob","overhead",
      "dropshot","backhand slice","forehand slice","pick-up shot","half volley"
    ];
    const summary: any = {};

    for (const shot of SHOTS) {
      const shots = analyses.filter((a) => a.shot_type === shot);
      if (shots.length === 0) continue;

      const text = shots.map((a) => a.analysis).join("\n");
      const misses: string[] = [];

      if (/(high enough follow through|low finish|not finishing)/i.test(text))
        misses.push("Your follow-through isn't high enough");
      if (/(bend your knees|not bending knees|stiff legs|need more leg drive)/i.test(text))
        misses.push("You aren't bending your knees enough");
      if (/(ball toss too low|toss is low|bad toss|toss inconsistent)/i.test(text))
        misses.push("Your ball toss is too low or inconsistent");
      if (/lose power/i.test(text)) misses.push("You're losing power on your shots");
      if (/(wrist too tight|tense wrist|relax wrist)/i.test(text))
        misses.push("You need to relax your wrist more");

      summary[shot] = { total: shots.length, misses };
    }

    res.json({ summary });
  } catch (e: any) {
    res.status(500).json({ error: e.message || "Failed to analyze shots" });
  }
});


// --- Auth: Get user from token ---
async function getUserFromAuthHeader(req: express.Request) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token) return null;
  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error) return null;
  return data.user; // { id, email, ... }
}

// --- AI ANALYSIS ENDPOINT ---
app.post("/api/analyze", upload.single("video"), async (req, res) => {
  const shotType = req.body.shotType;
  const username = req.body.username; // <---- from frontend!
  const videoPath = req.file.path;
  const videoData = fs.readFileSync(videoPath).toString("base64");

  // Structured Markdown Prompts for each shot
  const shotPrompts = {
    serve: `I have attached a video of someone hitting a tennis serve. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation
Ball toss
Racket preparation (backswing)
Leg drive
Contact point
Follow-through

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a serve:
1. Preparation and stance
- Left foot in front of right foot (for right-handed players)
- Body turned and perpendicular to the court
- Back (right) foot parallel to the baseline
- Left foot at about a 45-degree angle to the baseline
- Continental grip, holding at the bottom of the racket
- Loose grip and relaxed wrist

2. Ball toss
- Hold ball with fingertips so there’s no spin on the ball when tossing
- Toss with a straight arm, not a bent arm
- Release at eye level to forehead level
- Toss should consistently land about a foot inside the baseline
- Peak of the toss should be just above the fully extended racquet arm
- For a flat serve, toss at about one o’clock

3. Racket preparation (backswing)
- Racket drops behind your back, elbow pointed up
- Loose wrist
- Non-hitting arm extended up toward the ball
- Keep body turned

4. Leg drive
- Bend knees to generate power
- Explode upward with your legs as you swing
- For a pinpoint serve/coral step, do not bring right foot past left foot; keep body turned

5. Contact point
- Hit the ball as high as comfortably possible
- Hit the ball slightly in front, not directly above or behind the head
- Pronate wrist to increase power and spin
- Loose wrist, allowing racquet to snap into the ball
- Approach the ball with the racquet edge-on until pronation at the last second

6. Follow-through
- Arm comes across body to the opposite side
- Land inside the court on the front foot

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the server a letter grade on their serve (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    forehand: `I have attached a video of someone hitting a tennis forehand. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Unit turn and backswing
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a forehand:
1. Preparation and ready position
- Neutral, balanced stance with knees slightly bent
- Non-dominant hand supporting racquet throat
- Eyes on the ball and body facing the net

2. Unit turn and backswing
- Early shoulder turn as soon as the ball comes to the forehand side
- Racquet pulled back with the hitting arm relaxed
- Non-dominant hand pointing to the side or toward the ball for balance
- Racquet head above or level with the wrist (not too low, not too high)
- Weight transfer begins to back leg

3. Forward swing and contact point
- Step forward, shifting weight from back foot to front foot
- Hips and shoulders uncoil toward the net
- Racquet drops below the ball (“low to high” swing path)
- Contact point in front of the body, arm nearly fully extended
- Wrist relaxed, racquet face slightly closed for topspin

4. Follow-through and recovery
- Continue swinging up and across the body (finish high, “over the shoulder”)
- Non-dominant arm comes back for balance
- Return quickly to ready position

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their forehand (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    backhand: `I have attached a video of someone hitting a tennis backhand. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Unit turn and backswing
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a backhand:
1. Preparation and ready position
- Balanced stance, knees slightly bent
- Non-dominant hand on the racquet throat (or top handle for two-handed)
- Eyes on the incoming ball
- Body facing the net

2. Unit turn and backswing
- Early shoulder turn, racquet pulled back with both hands (two-handed) or dominant hand (one-handed)
- Non-dominant hand points to the side (one-handed) or remains on the handle (two-handed)
- Racquet head above or level with wrist
- Weight begins to shift to the back leg

3. Forward swing and contact point
- Step into the shot, transferring weight to front foot
- Hips and shoulders rotate toward the net
- Racquet drops below the ball for a low-to-high swing path
- Contact in front of the body, arm(s) extended
- Two-handed: Non-dominant hand drives the swing, dominant arm guides
- One-handed: Arm straight at contact, wrist firm, racquet face slightly closed for topspin

4. Follow-through and recovery
- Finish high, swinging up and across the body (over the shoulder for two-handed, out and upward for one-handed)
- Non-dominant arm moves back for balance (one-handed)
- Return quickly to ready position

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their backhand (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    volley: `I have attached a video of someone hitting a tennis volley. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Split step and movement to the ball
Backswing and racquet positioning
Contact point and punch
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a volley:
1. Preparation and ready position
- Knees slightly bent, weight on balls of feet
- Racquet held out in front, with a continental grip
- Hands relaxed, elbows away from body
- Eyes forward, alert for the ball

2. Split step and movement to the ball
- Timely split step just before opponent makes contact
- Quick, balanced movement toward the ball (small steps or lunge)
- Stay low and maintain balance

3. Backswing and racquet positioning
- Minimal or compact backswing—avoid large swings
- Racquet face slightly open, racquet head above the wrist
- Shoulder turn to prepare for forehand or backhand volley

4. Contact point and punch
- Contact ball in front of body, arm(s) slightly extended
- Use a controlled, short “punch” motion rather than a swing
- Firm wrist at contact
- Maintain racquet stability, face slightly open for underspin

5. Follow-through and recovery
- Short follow-through—racquet finishes out in front, not behind
- Recover quickly to ready position for the next shot

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their volley (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    "backhand slice": `I have attached a video of someone hitting a backhand slice. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Unit turn and setup
Backswing and racquet angle
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a backhand slice:
1. Preparation and ready position
- Continental grip, hand near the bottom of the handle
- Racquet out in front, body balanced with knees slightly bent
- Eyes on the incoming ball

2. Unit turn and setup
- Early shoulder turn as the ball approaches
- Non-dominant hand helps guide the racquet back and supports balance
- Weight shifts to the back foot
- Racquet brought high, well above the expected contact point

3. Backswing and racquet angle
- Racquet face slightly open (angled up)
- Racquet arm extended, but elbow relaxed
- Body side-on to the net, front shoulder pointing towards target

4. Forward swing and contact point
- Smooth, controlled downward and forward swing (“high to low” motion)
- Contact ball in front of body, arm extended but not locked
- Slice the ball with a brushing motion, generating backspin
- Firm but relaxed wrist at contact
- Step forward with front foot for weight transfer

5. Follow-through and recovery
- Racquet finishes low, out in front or slightly across the body
- Maintain balance and prepare quickly for the next shot

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their backhand slice (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    "forehand slice": `I have attached a video of someone hitting a forehand slice. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Unit turn and setup
Backswing and racquet angle
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a forehand slice:
1. Preparation and ready position
- Continental or eastern grip, hand near the bottom of the handle
- Racquet held out in front, body balanced, knees slightly bent
- Eyes focused on the incoming ball

2. Unit turn and setup
- Early shoulder turn as the ball approaches
- Non-dominant hand helps guide the racquet back for balance
- Weight shifts to the back foot
- Racquet prepared high, above the expected contact point

3. Backswing and racquet angle
- Racquet face slightly open (angled up)
- Racquet arm extended but relaxed
- Body side-on to the net, front shoulder pointing toward target

4. Forward swing and contact point
- Smooth, controlled downward and forward swing (“high to low” motion)
- Contact ball in front of the body, arm extended but not locked
- Slice the ball with a brushing motion to generate backspin
- Firm but relaxed wrist at contact
- Step forward with the front foot to transfer weight

5. Follow-through and recovery
- Racquet finishes low and out in front or slightly across the body
- Maintain balance and recover quickly for the next shot

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their forehand slice (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    overhead: `I have attached a video of someone hitting an overhead (smash). Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Movement and positioning under the ball
Racket preparation (backswing)
Swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in an overhead:
1. Preparation and ready position
- Racquet up and in a “ready” position, using a continental grip
- Non-dominant hand up, pointing at the incoming ball
- Knees slightly bent, weight on balls of feet
- Eyes on the ball, alert and balanced

2. Movement and positioning under the ball
- Quick adjustment steps to get directly under the ball
- Body side-on to the net, turning shoulders early
- Maintain balance and avoid backpedaling; use shuffle or cross steps

3. Racket preparation (backswing)
- Racquet drops behind the back (“trophy position”)
- Non-dominant hand extended up, tracking the ball
- Elbow bent, wrist relaxed

4. Swing and contact point
- Drive up with legs, reaching high to meet the ball at full extension
- Contact the ball slightly in front of the body
- Pronation of the wrist at contact for power and control
- Eyes on the ball through contact

5. Follow-through and recovery
- Full follow-through, arm finishing across the body
- Land inside the court, ready for the next shot
- Regain balanced position quickly

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their overhead (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    dropshot: `I have attached a video of someone hitting a dropshot. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Unit turn and setup
Backswing and racquet angle
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a dropshot:
1. Preparation and ready position
- Soft hands on grip, relaxed wrist
- Racquet face open, body balanced, knees slightly bent
- Eyes on ball

2. Unit turn and setup
- Early shoulder turn as the ball approaches
- Racquet pulled back softly, not tense
- Weight on front foot

3. Backswing and racquet angle
- Minimal backswing
- Racquet face open and below the ball
- Wrist relaxed

4. Forward swing and contact point
- Gentle, brushing motion under ball
- Contact ball in front of body, just above net height
- Very short swing, soft touch

5. Follow-through and recovery
- Minimal follow-through, racquet finishes out in front
- Quickly recover to ready position for next shot

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their dropshot (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    lob: `I have attached a video of someone hitting a tennis lob. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Unit turn and setup
Backswing and racquet positioning
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a lob:
1. Preparation and ready position
- Balanced stance, knees slightly bent
- Racquet held out in front, eyes focused on the incoming ball
- Grip suitable for topspin or slice lob (usually eastern or continental)

2. Unit turn and setup
- Early shoulder turn, racquet taken back smoothly
- Weight shifts to back foot
- Non-dominant hand helps guide the racquet and maintain balance

3. Backswing and racquet positioning
- For topspin lob: racquet drops below the ball, ready for a low-to-high swing
- For slice lob: racquet face slightly open, backswing is higher and more compact
- Body remains side-on to the net

4. Forward swing and contact point
- For topspin: accelerate racquet upward, brushing up the back of the ball for height and spin
- For slice: controlled, high-to-low motion, lifting the ball with an open face
- Contact point in front of body, arm(s) extended but relaxed
- Focus on lifting the ball high and deep

5. Follow-through and recovery
- For topspin: racquet finishes high above shoulder
- For slice: racquet follows through toward target, not across the body
- Recover quickly to ready position for next shot

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their lob (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    "pick-up shot": `I have attached a video of someone hitting a pick-up shot (half-volley or scoop shot). Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Movement and positioning
Backswing and racquet angle
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a pick-up shot (half-volley):
1. Preparation and ready position
- Balanced, low stance with knees bent
- Racquet held out in front (continental or eastern grip recommended)
- Eyes focused on the oncoming ball

2. Movement and positioning
- Quick, small adjustment steps to get body behind and low to the ball
- Weight forward, chest over the ball
- Stay balanced—avoid reaching or lunging if possible

3. Backswing and racquet angle
- Very short or almost no backswing—racquet prepared low and close to the ground
- Racquet face slightly open to help lift the ball
- Wrist relaxed, racquet head stable

4. Forward swing and contact point
- Smooth, controlled forward motion with minimal swing
- Contact ball just after it bounces, as close to the ground as possible
- Use the body and legs to help “scoop” the ball up, not just the arm
- Firm but gentle wrist at contact for control

5. Follow-through and recovery
- Short follow-through, racquet stays in front or just past contact point
- Regain balance and return quickly to ready position

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their pick-up shot (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
    "half volley": `I have attached a video of someone hitting a half volley. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I’d like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation and ready position
Movement and positioning
Backswing and racquet angle
Forward swing and contact point
Follow-through and recovery

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I’m looking for constructive feedback that’s easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a half volley:
1. Preparation and ready position
- Stay low, knees deeply bent
- Racquet prepared out in front with a continental grip
- Eyes focused on the oncoming ball

2. Movement and positioning
- Quick, small steps to get in line with the bounce
- Body weight forward, chest over the ball
- Minimal backswing, racquet close to ground

3. Backswing and racquet angle
- Very short, compact backswing
- Racquet face slightly open
- Wrist relaxed

4. Forward swing and contact point
- Minimal swing, controlled push through the ball
- Contact ball just after bounce, as low as possible
- Use legs to drive through, not just arm

5. Follow-through and recovery
- Short follow-through, racquet finishes in front
- Quickly recover to ready position

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the player a letter grade on their half volley (A+ to F), along with a brief summary of what they’re doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header (Summary, Analysis, Three Tips for Improvement) starts on its own line and each bullet/numbered tip starts on a new line. Do not combine sections on the same line.

Example:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.
- Fourth point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.

Use **real** Markdown with proper line breaks, not inline bold headers or a single paragraph.`,
  };

  const prompt =
    shotPrompts[shotType] ||
    `You are an expert tennis coach. Analyze this tennis shot video. Return your response in the same Markdown format as the earlier examples.`;

  try {
    const geminiRes = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" +
        GEMINI_API_KEY,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: prompt },
                { inlineData: { mimeType: "video/mp4", data: videoData } },
              ],
            },
          ],
        }),
      },
    );
    const data = await geminiRes.json();
    let analysis =
      data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      "No analysis returned.";
    analysis = prettifyGeminiMarkdown(analysis); // Post-process for pretty output

    fs.unlinkSync(videoPath);
    res.json({ analysis });
  } catch (e) {
    fs.unlinkSync(videoPath);
    res.status(500).json({ error: "Gemini API call failed." });
  }
});

// --- Accounts: list all signed-up users with placeholder fields ---
app.get("/api/accounts", async (req, res) => {
  try {
    // Uses your existing supabaseAdmin (service role)
    const { data, error } = await supabaseAdmin.auth.admin.listUsers();
    if (error) return res.status(500).json({ error: error.message });

    const users = (data?.users || []).map((u: any) => ({
      id: u.id,
      email: u.email,
      // Placeholder profile fields (use user_metadata if you later store these)
      name: u.user_metadata?.name ?? "",
      age: u.user_metadata?.age ?? "",
      ability: u.user_metadata?.ability ?? "",
      photo: u.user_metadata?.photo ?? null,
      // add anything else you want to display later:
      location: u.user_metadata?.location ?? "",
      handedness: u.user_metadata?.handedness ?? "",
    }));

    res.json(users);
  } catch (e: any) {
    res.status(500).json({ error: e.message || "Failed to fetch accounts" });
  }
});


// --- COACH LISTING (Simple file-based, can use a DB for real) ---
const COACHES_FILE = "./coaches.json";

app.get("/api/coaches", (req, res) => {
  if (!fs.existsSync(COACHES_FILE)) fs.writeFileSync(COACHES_FILE, "[]");
  const coaches = JSON.parse(fs.readFileSync(COACHES_FILE));
  res.json(coaches);
});

app.post("/api/coaches", upload.single("photo"), (req, res) => {
  let coaches = [];
  if (fs.existsSync(COACHES_FILE))
    coaches = JSON.parse(fs.readFileSync(COACHES_FILE));
  const { name, hours, description, rates } = req.body;
  const photo = req.file ? `/uploads/${req.file.filename}` : null;
  const coach = { id: Date.now(), name, hours, description, rates, photo };
  coaches.push(coach);
  fs.writeFileSync(COACHES_FILE, JSON.stringify(coaches, null, 2));
  res.json(coach);
});

app.post("/api/message", (req, res) => {
  const { coachId, playerName, message } = req.body;
  res.json({ ok: true });
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));
