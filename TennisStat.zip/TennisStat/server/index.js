import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import multer from "multer";

const app = express();
const upload = multer({ dest: "uploads/" });

const GEMINI_API_KEY = "AIzaSyDcIe-pmIqI8RSpUVeB01tTif_5KYPFc9g"; // Replace with your own key!

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

// --- Serve the built React app ---
app.use(express.static(path.join(process.cwd(), "..", "client", "dist")));
app.get("*", (req, res) => {
  res.sendFile(path.join(process.cwd(), "..", "client", "dist", "index.html"));
});

// --- Helper: Post-process and prettify Gemini Markdown output ---
function prettifyGeminiMarkdown(md) {
  // Ensure each major header starts on a new line with blank lines around
  md = md.replace(
    /\*\*(Summary|Analysis|Three Tips for Improvement):\*\*/g,
    "\n\n**$1:**\n",
  );
  // Replace any inline " - " with real markdown bullets
  md = md.replace(/ - /g, "\n- ");
  // Replace " 1. ", " 2. ", etc. with numbered lists on new lines
  md = md.replace(/ (\d+)\. /g, "\n$1. ");
  // Fix double or more blank lines to just double
  md = md.replace(/\n{3,}/g, "\n\n");
  return md.trim();
}

// --- AI ANALYSIS ENDPOINT ---
app.post("/api/analyze", upload.single("video"), async (req, res) => {
  try {
    const shotType = req.body.shotType;
    const videoPath = req.file?.path;
    
    if (!videoPath) {
      return res.status(400).json({ error: "No video file provided" });
    }

    const videoData = fs.readFileSync(videoPath).toString("base64");

    // Structured Markdown Prompts for each shot
    const shotPrompts = {
      serve: `I have attached a video of someone hitting a tennis serve. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Specifically, I'd like you to:
Point out any flaws or mistakes in their form.
Break down the feedback into the following stages:
Preparation
Ball toss
Racket preparation (backswing)
Leg drive
Contact point
Follow-through

Highlight any issues you notice at each stage.
Suggest practical advice or specific drills to address these issues.

I'm looking for constructive feedback that's easy to understand and apply, so please include clear suggestions on how to fix any mistakes you observe.

For reference, here are the key elements I want to see in a serve:
1. Preparation and stance
- Left foot in front of right foot (for right-handed players)
- Body turned and perpendicular to the court
- Back (right) foot parallel to the baseline
- Left foot at about a 45-degree angle to the baseline
- Continental grip, holding at the bottom of the racket
- Loose grip and relaxed wrist

2. Ball toss
- Hold ball with fingertips so there's no spin on the ball when tossing
- Toss with a straight arm, not a bent arm
- Release at eye level to forehead level
- Toss should consistently land about a foot inside the baseline
- Peak of the toss should be just above the fully extended racquet arm
- For a flat serve, toss at about one o'clock

3. Racket preparation (backswing)
- Racket drops behind your back, elbow pointed up
- Loose wrist
- Non-hitting arm extended up toward the ball
- Keep body turned

4. Leg drive
- Bend knees to generate power
- Explode upward with your legs as you swing
- For a pinpoint serve/coral step, do not bring right foot past left foot; keep body turned

5. Contact point
- Hit the ball as high as comfortably possible
- Hit the ball slightly in front, not directly above or behind the head
- Pronate wrist to increase power and spin
- Loose wrist, allowing racquet to snap into the ball
- Approach the ball with the racquet edge-on until pronation at the last second

6. Follow-through
- Arm comes across body to the opposite side
- Land inside the court on the front foot

Please analyze each stage based on these criteria, point out any deviations, and give me specific, actionable steps or drills for improvement.

Finally, please give the server a letter grade on their serve (A+ to F), along with a brief summary of what they're doing well and what should be their top priorities for improvement.

Return your response in the following Markdown format, making sure each section header starts on its own line:

**Summary:**  
Your summary sentence here.

**Analysis:**  
- First point.
- Second point.
- Third point.

**Three Tips for Improvement:**  
1. Tip one.
2. Tip two.
3. Tip three.`,
      
      forehand: `I have attached a video of someone hitting a tennis forehand. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Please follow the same format as the serve analysis, focusing on forehand-specific technique points.

Return your response in proper Markdown format with clear section headers.`,
      
      backhand: `I have attached a video of someone hitting a tennis backhand. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Please follow the same format as the serve analysis, focusing on backhand-specific technique points.

Return your response in proper Markdown format with clear section headers.`,
      
      volley: `I have attached a video of someone hitting a tennis volley. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Please follow the same format as the serve analysis, focusing on volley-specific technique points.

Return your response in proper Markdown format with clear section headers.`,
      
      "backhand slice": `I have attached a video of someone hitting a backhand slice. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Please follow the same format as the serve analysis, focusing on slice-specific technique points.

Return your response in proper Markdown format with clear section headers.`,
      
      "forehand slice": `I have attached a video of someone hitting a forehand slice. Please analyze their technique and provide detailed, actionable feedback on what can be improved.

Please follow the same format as the serve analysis, focusing on slice-specific technique points.

Return your response in proper Markdown format with clear section headers.`
    };

    const prompt = shotPrompts[shotType] || shotPrompts.serve;

    const requestBody = {
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inline_data: {
                mime_type: "video/mp4",
                data: videoData,
              },
            },
          ],
        },
      ],
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      }
    );

    const data = await response.json();
    
    if (!response.ok) {
      console.error("Gemini API error:", data);
      return res.status(500).json({ 
        error: "Failed to analyze video", 
        details: data.error?.message || "Unknown error" 
      });
    }

    if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
      const rawAnalysis = data.candidates[0].content.parts[0].text;
      const analysis = prettifyGeminiMarkdown(rawAnalysis);

      // Clean up the video file
      fs.unlinkSync(videoPath);

      res.json({ analysis });
    } else {
      console.error("Unexpected Gemini response structure:", data);
      res.status(500).json({ 
        error: "Unexpected response from analysis service",
        details: "Unable to extract analysis from response"
      });
    }
  } catch (error) {
    console.error("Error in /api/analyze:", error);
    res.status(500).json({ 
      error: "Internal server error", 
      details: error.message 
    });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on ${PORT}`);
});